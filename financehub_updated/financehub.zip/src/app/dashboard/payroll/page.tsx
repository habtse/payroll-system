"use client"

import * as React from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { employees, salaries, bonuses, payrolls } from "@/lib/dummy-data"
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils"
import { Payroll } from "@/types"

export default function PayrollPage() {
  const [searchTerm, setSearchTerm] = React.useState("")
  const [payrolls, setPayrolls] = React.useState<Payroll[]>([])
  const [isLoading, setIsLoading] = React.useState(true)
  const [selectedPayroll, setSelectedPayroll] = React.useState<Payroll | null>(null)
  const [selectedEmployees, setSelectedEmployees] = React.useState<string[]>([])
  const [isProcessDialogOpen, setIsProcessDialogOpen] = React.useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = React.useState(false)
  const [currentMonth, setCurrentMonth] = React.useState(5) // May (0-indexed would be 4, but we're using 1-indexed for display)
  const [currentYear, setCurrentYear] = React.useState(2025)

  // Fetch payrolls on component mount
  React.useEffect(() => {
    const fetchPayrolls = async () => {
      try {
        // In a real app, this would be an API call
        // const response = await fetch('/api/payrolls');
        // const data = await response.json();
        
        // Using dummy data instead
        const data = await import('@/lib/dummy-data').then(module => module.payrolls);
        setPayrolls(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching payrolls:', error);
        setIsLoading(false);
      }
    };

    fetchPayrolls();
  }, []);

  // Filter payrolls based on search term
  const filteredPayrolls = React.useMemo(() => {
    return payrolls.filter(payroll => {
      const employee = employees.find(emp => emp.id === payroll.employeeId);
      const employeeName = employee ? `${employee.firstName} ${employee.lastName}` : '';
      
      return (
        employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payroll.paymentStatus.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payroll.netSalary.toString().includes(searchTerm)
      );
    });
  }, [payrolls, searchTerm]);

  // Get employee name by ID
  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find(emp => emp.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown Employee';
  };

  // Get month name
  const getMonthName = (month: number) => {
    const months = [
      'January', 'February', 'March', 'April', 
      'May', 'June', 'July', 'August', 
      'September', 'October', 'November', 'December'
    ];
    return months[month - 1];
  };

  // Handle bulk payroll processing
  const handleProcessPayroll = async (formData: FormData) => {
    // In a real app, this would be an API call
    // const response = await fetch('/api/payrolls/process', {
    //   method: 'POST',
    //   body: formData
    // });
    
    // For demo, just close the dialog
    setIsProcessDialogOpen(false);
    setSelectedEmployees([]);
  };

  // Toggle employee selection for bulk processing
  const toggleEmployeeSelection = (employeeId: string) => {
    setSelectedEmployees(prev => 
      prev.includes(employeeId)
        ? prev.filter(id => id !== employeeId)
        : [...prev, employeeId]
    );
  };

  // Check if all employees are selected
  const allEmployeesSelected = employees.length === selectedEmployees.length;

  // Toggle all employees selection
  const toggleAllEmployees = () => {
    if (allEmployeesSelected) {
      setSelectedEmployees([]);
    } else {
      setSelectedEmployees(employees.map(emp => emp.id));
    }
  };

  // Calculate payroll summary
  const payrollSummary = React.useMemo(() => {
    const totalNetSalary = payrolls.reduce((sum, p) => sum + p.netSalary, 0);
    const totalGrossSalary = payrolls.reduce((sum, p) => sum + p.grossEarnings, 0);
    const totalDeductions = payrolls.reduce((sum, p) => sum + p.totalDeductions, 0);
    const totalBonus = payrolls.reduce((sum, p) => sum + p.totalBonus, 0);
    
    return {
      totalNetSalary,
      totalGrossSalary,
      totalDeductions,
      totalBonus,
      employeeCount: payrolls.length
    };
  }, [payrolls]);

  // Generate employees for current month that don't have payrolls yet
  const employeesWithoutPayroll = React.useMemo(() => {
    const employeesWithPayroll = payrolls
      .filter(p => p.month === currentMonth && p.year === currentYear)
      .map(p => p.employeeId);
    
    return employees.filter(emp => !employeesWithPayroll.includes(emp.id));
  }, [payrolls, currentMonth, currentYear]);

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Payroll Management</h1>
        <Button onClick={() => setIsProcessDialogOpen(true)}>Process Payroll</Button>
      </div>

      <Tabs defaultValue="current" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="current">Current Payroll</TabsTrigger>
          <TabsTrigger value="history">Payroll History</TabsTrigger>
          <TabsTrigger value="summary">Payroll Summary</TabsTrigger>
        </TabsList>
        
        {/* Current Payroll Tab */}
        <TabsContent value="current" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Current Month Payroll - {getMonthName(currentMonth)} {currentYear}</CardTitle>
              <CardDescription>
                Process and manage current month payroll
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-6">
                <div className="w-1/3">
                  <Input
                    placeholder="Search employees..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setCurrentMonth(prev => prev > 1 ? prev - 1 : 12)}>
                    Previous Month
                  </Button>
                  <Button variant="outline" onClick={() => setCurrentMonth(prev => prev < 12 ? prev + 1 : 1)}>
                    Next Month
                  </Button>
                </div>
              </div>

              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox 
                            checked={allEmployeesSelected} 
                            onCheckedChange={toggleAllEmployees}
                          />
                        </TableHead>
                        <TableHead>Employee</TableHead>
                        <TableHead>Basic Salary</TableHead>
                        <TableHead>Allowances</TableHead>
                        <TableHead>Deductions</TableHead>
                        <TableHead>Bonus</TableHead>
                        <TableHead>Net Salary</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employeesWithoutPayroll.length === 0 && filteredPayrolls.filter(p => p.month === currentMonth && p.year === currentYear).length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={9} className="text-center py-10">
                            No payroll data for {getMonthName(currentMonth)} {currentYear}
                          </TableCell>
                        </TableRow>
                      ) : (
                        <>
                          {/* Employees with processed payroll */}
                          {filteredPayrolls
                            .filter(p => p.month === currentMonth && p.year === currentYear)
                            .map((payroll) => {
                              const employee = employees.find(emp => emp.id === payroll.employeeId);
                              return (
                                <TableRow key={payroll.id}>
                                  <TableCell>
                                    <Checkbox 
                                      checked={selectedEmployees.includes(payroll.employeeId)}
                                      onCheckedChange={() => toggleEmployeeSelection(payroll.employeeId)}
                                    />
                                  </TableCell>
                                  <TableCell>
                                    {employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown Employee'}
                                  </TableCell>
                                  <TableCell>{formatCurrency(payroll.basicSalary)}</TableCell>
                                  <TableCell>{formatCurrency(payroll.totalAllowances)}</TableCell>
                                  <TableCell>{formatCurrency(payroll.totalDeductions)}</TableCell>
                                  <TableCell>{formatCurrency(payroll.totalBonus)}</TableCell>
                                  <TableCell>{formatCurrency(payroll.netSalary)}</TableCell>
                                  <TableCell>
                                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(payroll.paymentStatus)}`}>
                                      {payroll.paymentStatus}
                                    </span>
                                  </TableCell>
                                  <TableCell className="text-right">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => {
                                        setSelectedPayroll(payroll);
                                        setIsViewDialogOpen(true);
                                      }}
                                    >
                                      View
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                    >
                                      Pay Slip
                                    </Button>
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          
                          {/* Employees without processed payroll */}
                          {employeesWithoutPayroll.map((employee) => {
                            const employeeSalary = salaries.find(s => s.employeeId === employee.id);
                            const employeeBonus = bonuses
                              .filter(b => b.employeeId === employee.id && b.status === 'approved')
                              .reduce((sum, b) => sum + b.amount, 0);
                            
                            return (
                              <TableRow key={employee.id} className="bg-muted/20">
                                <TableCell>
                                  <Checkbox 
                                    checked={selectedEmployees.includes(employee.id)}
                                    onCheckedChange={() => toggleEmployeeSelection(employee.id)}
                                  />
                                </TableCell>
                                <TableCell>
                                  {`${employee.firstName} ${employee.lastName}`}
                                </TableCell>
                                <TableCell>{employeeSalary ? formatCurrency(employeeSalary.basicSalary) : 'N/A'}</TableCell>
                                <TableCell>{employeeSalary ? formatCurrency(
                                  employeeSalary.houseRentAllowance + 
                                  employeeSalary.transportAllowance + 
                                  employeeSalary.medicalAllowance + 
                                  employeeSalary.otherAllowances
                                ) : 'N/A'}</TableCell>
                                <TableCell>{employeeSalary ? formatCurrency(
                                  employeeSalary.taxDeduction + employeeSalary.otherDeductions
                                ) : 'N/A'}</TableCell>
                                <TableCell>{formatCurrency(employeeBonus)}</TableCell>
                                <TableCell>{employeeSalary ? formatCurrency(employeeSalary.netSalary + employeeBonus) : 'N/A'}</TableCell>
                                <TableCell>
                                  <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                                    Pending
                                  </span>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    disabled
                                  >
                                    Not Processed
                                  </Button>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
              
              {selectedEmployees.length > 0 && (
                <div className="mt-4 p-4 bg-muted rounded-md flex justify-between items-center">
                  <div>
                    <span className="font-medium">{selectedEmployees.length} employee{selectedEmployees.length > 1 ? 's' : ''} selected</span>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setSelectedEmployees([])}>
                      Clear Selection
                    </Button>
                    <Button onClick={() => setIsProcessDialogOpen(true)}>
                      Process Selected
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Payroll History Tab */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payroll History</CardTitle>
              <CardDescription>
                View and manage historical payroll records
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-6">
                <div className="w-1/3">
                  <Input
                    placeholder="Search payroll history..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
              </div>

              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Month/Year</TableHead>
                        <TableHead>Net Salary</TableHead>
                        <TableHead>Payment Status</TableHead>
                        <TableHead>Payment Date</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPayrolls.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-10">
                            No payroll history found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredPayrolls.map((payroll) => (
                          <TableRow key={payroll.id}>
                            <TableCell>{getEmployeeName(payroll.employeeId)}</TableCell>
                            <TableCell>{getMonthName(payroll.month)} {payroll.year}</TableCell>
                            <TableCell>{formatCurrency(payroll.netSalary)}</TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(payroll.paymentStatus)}`}>
                                {payroll.paymentStatus}
                              </span>
                            </TableCell>
                            <TableCell>{payroll.paymentDate ? formatDate(payroll.paymentDate) : 'Pending'}</TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setSelectedPayroll(payroll);
                                  setIsViewDialogOpen(true);
                                }}
                              >
                                View
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                              >
                                Pay Slip
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Payroll Summary Tab */}
        <TabsContent value="summary" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Net Salary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(payrollSummary.totalNetSalary)}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Gross Salary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(payrollSummary.totalGrossSalary)}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Deductions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(payrollSummary.totalDeductions)}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Bonuses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(payrollSummary.totalBonus)}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Payroll by Department</CardTitle>
              <CardDescription>
                Summary of payroll distribution by department
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Department</TableHead>
                      <TableHead>Employees</TableHead>
                      <TableHead>Total Salary</TableHead>
                      <TableHead>Average Salary</TableHead>
                      <TableHead>Highest Salary</TableHead>
                      <TableHead>Lowest Salary</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* Group by department and calculate stats */}
                    {Object.entries(
                      employees.reduce((acc, employee) => {
                        const employeePayroll = payrolls.find(p => p.employeeId === employee.id);
                        if (!employeePayroll) return acc;
                        
                        if (!acc[employee.department]) {
                          acc[employee.department] = {
                            count: 0,
                            total: 0,
                            salaries: []
                          };
                        }
                        
                        acc[employee.department].count += 1;
                        acc[employee.department].total += employeePayroll.netSalary;
                        acc[employee.department].salaries.push(employeePayroll.netSalary);
                        
                        return acc;
                      }, {} as Record<string, { count: number, total: number, salaries: number[] }>)
                    ).map(([department, data]) => (
                      <TableRow key={department}>
                        <TableCell>{department}</TableCell>
                        <TableCell>{data.count}</TableCell>
                        <TableCell>{formatCurrency(data.total)}</TableCell>
                        <TableCell>{formatCurrency(data.total / data.count)}</TableCell>
                        <TableCell>{formatCurrency(Math.max(...data.salaries))}</TableCell>
                        <TableCell>{formatCurrency(Math.min(...data.salaries))}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Payroll Actions</CardTitle>
              <CardDescription>
                Common payroll operations and reports
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Generate Tax Reports
                </Button>
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Export Payroll Data
                </Button>
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  Email Pay Slips
                </Button>
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  Bulk Generate Pay Slips
                </Button>
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Payroll Calendar
                </Button>
                <Button variant="outline" className="h-24 flex flex-col items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  Payroll Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Process Payroll Dialog */}
      <Dialog open={isProcessDialogOpen} onOpenChange={setIsProcessDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Process Payroll</DialogTitle>
          </DialogHeader>
          <form className="grid gap-4 py-4" onSubmit={(e) => {
            e.preventDefault();
            handleProcessPayroll(new FormData(e.currentTarget));
          }}>
            <div className="grid gap-2">
              <label htmlFor="payrollMonth">Payroll Month</label>
              <select id="payrollMonth" name="payrollMonth" defaultValue={currentMonth} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>{getMonthName(i + 1)}</option>
                ))}
              </select>
            </div>
            <div className="grid gap-2">
              <label htmlFor="payrollYear">Payroll Year</label>
              <select id="payrollYear" name="payrollYear" defaultValue={currentYear} className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                {[2024, 2025, 2026].map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
            <div className="grid gap-2">
              <label htmlFor="paymentDate">Payment Date</label>
              <Input id="paymentDate" name="paymentDate" type="date" required />
            </div>
            <div className="grid gap-2">
              <label>Selected Employees ({selectedEmployees.length})</label>
              <div className="max-h-40 overflow-y-auto border rounded-md p-2">
                {selectedEmployees.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No employees selected</p>
                ) : (
                  <ul className="space-y-1">
                    {selectedEmployees.map(id => {
                      const employee = employees.find(e => e.id === id);
                      return (
                        <li key={id} className="text-sm flex justify-between">
                          <span>{employee ? `${employee.firstName} ${employee.lastName}` : id}</span>
                          <Button 
                            type="button" 
                            variant="ghost" 
                            size="sm" 
                            className="h-5 text-red-500 hover:text-red-700 p-0"
                            onClick={() => toggleEmployeeSelection(id)}
                          >
                            Remove
                          </Button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
            <div className="grid gap-2">
              <label htmlFor="notes">Notes (Optional)</label>
              <textarea
                id="notes"
                name="notes"
                className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                placeholder="Add any notes about this payroll processing"
              />
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button type="button" variant="outline" onClick={() => setIsProcessDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={selectedEmployees.length === 0}>
                Process Payroll
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Payroll Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Payroll Details</DialogTitle>
          </DialogHeader>
          {selectedPayroll && (
            <div className="py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium text-sm text-muted-foreground">Employee</h3>
                  <p>{getEmployeeName(selectedPayroll.employeeId)}</p>
                </div>
                <div>
                  <h3 className="font-medium text-sm text-muted-foreground">Period</h3>
                  <p>{getMonthName(selectedPayroll.month)} {selectedPayroll.year}</p>
                </div>
              </div>
              
              <div className="mt-6">
                <h3 className="font-medium text-base border-b pb-2 mb-3">Earnings</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Basic Salary</h3>
                    <p>{formatCurrency(selectedPayroll.basicSalary)}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Total Allowances</h3>
                    <p>{formatCurrency(selectedPayroll.totalAllowances)}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-3">
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Bonus</h3>
                    <p>{formatCurrency(selectedPayroll.totalBonus)}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Gross Earnings</h3>
                    <p className="font-semibold">{formatCurrency(selectedPayroll.grossEarnings)}</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <h3 className="font-medium text-base border-b pb-2 mb-3">Deductions</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Total Deductions</h3>
                    <p>{formatCurrency(selectedPayroll.totalDeductions)}</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 border-t pt-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Net Salary</h3>
                    <p className="font-bold text-lg">{formatCurrency(selectedPayroll.netSalary)}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground">Payment Status</h3>
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(selectedPayroll.paymentStatus)}`}>
                      {selectedPayroll.paymentStatus}
                    </span>
                  </div>
                </div>
                {selectedPayroll.paymentDate && (
                  <div className="grid grid-cols-2 gap-4 mt-3">
                    <div>
                      <h3 className="font-medium text-sm text-muted-foreground">Payment Date</h3>
                      <p>{formatDate(selectedPayroll.paymentDate)}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Close
            </Button>
            <Button>
              Generate Pay Slip
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
