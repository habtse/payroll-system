"use client"

import * as React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { payslips, payrolls, employees, currentTenant } from "@/lib/dummy-data"
import { formatCurrency, formatDate, getMonthName } from "@/lib/utils"
import { PaySlip } from "@/types"

export default function PaySlipsPage() {
  const [searchTerm, setSearchTerm] = React.useState("")
  const [payslips, setPayslips] = React.useState<PaySlip[]>([])
  const [isLoading, setIsLoading] = React.useState(true)
  const [selectedPayslip, setSelectedPayslip] = React.useState<PaySlip | null>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = React.useState(false)
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = React.useState(false)

  // Fetch payslips on component mount
  React.useEffect(() => {
    const fetchPayslips = async () => {
      try {
        // In a real app, this would be an API call
        // const response = await fetch('/api/payslips');
        // const data = await response.json();
        
        // Using dummy data instead
        const data = await import('@/lib/dummy-data').then(module => module.payslips);
        setPayslips(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching payslips:', error);
        setIsLoading(false);
      }
    };

    fetchPayslips();
  }, []);

  // Filter payslips based on search term
  const filteredPayslips = React.useMemo(() => {
    return payslips.filter(payslip => {
      const employee = employees.find(emp => emp.id === payslip.employeeId);
      const employeeName = employee ? `${employee.firstName} ${employee.lastName}` : '';
      
      return (
        employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        `${getMonthName(payslip.month)} ${payslip.year}`.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [payslips, searchTerm]);

  // Get employee name by ID
  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find(emp => emp.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown Employee';
  };

  // Get payroll details for a payslip
  const getPayrollDetails = (payrollId: string) => {
    return payrolls.find(payroll => payroll.id === payrollId);
  };

  // Handle bulk generation of payslips
  const handleBulkGeneration = () => {
    // In a real app, this would be an API call
    // const response = await fetch('/api/payslips/bulk-generate', {
    //   method: 'POST',
    //   body: JSON.stringify({ month: currentMonth, year: currentYear })
    // });
    
    // For demo, just show a success message
    alert('Bulk generation initiated. Payslips will be available shortly.');
  };

  // Handle email distribution
  const handleEmailDistribution = () => {
    // In a real app, this would be an API call
    // const response = await fetch('/api/payslips/email-distribution', {
    //   method: 'POST',
    //   body: JSON.stringify({ payslipIds: selectedPayslips })
    // });
    
    // For demo, just show a success message
    alert('Email distribution initiated. Payslips will be sent to employees.');
  };

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Pay Slips</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleEmailDistribution}>Email Pay Slips</Button>
          <Button onClick={handleBulkGeneration}>Generate Pay Slips</Button>
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Pay Slip Management</CardTitle>
          <CardDescription>
            Generate, view, and distribute pay slips to employees
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-6">
            <div className="w-1/3">
              <Input
                placeholder="Search pay slips..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Generated On</TableHead>
                    <TableHead>Net Salary</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayslips.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-10">
                        No pay slips found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredPayslips.map((payslip) => {
                      const payroll = getPayrollDetails(payslip.payrollId);
                      return (
                        <TableRow key={payslip.id}>
                          <TableCell>{getEmployeeName(payslip.employeeId)}</TableCell>
                          <TableCell>{getMonthName(payslip.month)} {payslip.year}</TableCell>
                          <TableCell>{formatDate(payslip.generatedOn)}</TableCell>
                          <TableCell>{payroll ? formatCurrency(payroll.netSalary) : 'N/A'}</TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedPayslip(payslip);
                                setIsViewDialogOpen(true);
                              }}
                            >
                              View Details
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setSelectedPayslip(payslip);
                                setIsPreviewDialogOpen(true);
                              }}
                            >
                              Preview
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                            >
                              Download
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Pay Slip Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Pay Slip Details</DialogTitle>
          </DialogHeader>
          {selectedPayslip && (
            <div className="py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-medium text-sm text-muted-foreground">Employee</h3>
                  <p>{getEmployeeName(selectedPayslip.employeeId)}</p>
                </div>
                <div>
                  <h3 className="font-medium text-sm text-muted-foreground">Period</h3>
                  <p>{getMonthName(selectedPayslip.month)} {selectedPayslip.year}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <h3 className="font-medium text-sm text-muted-foreground">Generated On</h3>
                  <p>{formatDate(selectedPayslip.generatedOn)}</p>
                </div>
                <div>
                  <h3 className="font-medium text-sm text-muted-foreground">Download URL</h3>
                  <p className="text-blue-600">{selectedPayslip.downloadUrl || 'N/A'}</p>
                </div>
              </div>
              {selectedPayslip.payrollId && (
                <div className="mt-6">
                  <h3 className="font-medium text-base border-b pb-2 mb-3">Payroll Information</h3>
                  {(() => {
                    const payroll = getPayrollDetails(selectedPayslip.payrollId);
                    if (!payroll) return <p>Payroll information not available</p>;
                    
                    return (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h3 className="font-medium text-sm text-muted-foreground">Basic Salary</h3>
                            <p>{formatCurrency(payroll.basicSalary)}</p>
                          </div>
                          <div>
                            <h3 className="font-medium text-sm text-muted-foreground">Total Allowances</h3>
                            <p>{formatCurrency(payroll.totalAllowances)}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 mt-3">
                          <div>
                            <h3 className="font-medium text-sm text-muted-foreground">Total Deductions</h3>
                            <p>{formatCurrency(payroll.totalDeductions)}</p>
                          </div>
                          <div>
                            <h3 className="font-medium text-sm text-muted-foreground">Total Bonus</h3>
                            <p>{formatCurrency(payroll.totalBonus)}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 mt-3">
                          <div>
                            <h3 className="font-medium text-sm text-muted-foreground">Gross Earnings</h3>
                            <p>{formatCurrency(payroll.grossEarnings)}</p>
                          </div>
                          <div>
                            <h3 className="font-medium text-sm text-muted-foreground">Net Salary</h3>
                            <p className="font-bold">{formatCurrency(payroll.netSalary)}</p>
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </div>
              )}
            </div>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Close
            </Button>
            <Button>
              Download Pay Slip
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Pay Slip Dialog */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>Pay Slip Preview</DialogTitle>
          </DialogHeader>
          {selectedPayslip && (
            <div className="py-4">
              <div className="border rounded-md p-8 bg-white">
                {/* Pay Slip Header */}
                <div className="flex justify-between items-center border-b pb-4 mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800">{currentTenant.name}</h2>
                    <p className="text-gray-600">{currentTenant.address}</p>
                    <p className="text-gray-600">{currentTenant.contactEmail} | {currentTenant.contactPhone}</p>
                  </div>
                  <div className="text-right">
                    <h3 className="text-xl font-bold text-gray-800">PAY SLIP</h3>
                    <p className="text-gray-600">For the month of {getMonthName(selectedPayslip.month)} {selectedPayslip.year}</p>
                  </div>
                </div>

                {/* Employee Information */}
                {(() => {
                  const employee = employees.find(emp => emp.id === selectedPayslip.employeeId);
                  if (!employee) return <p>Employee information not available</p>;
                  
                  return (
                    <div className="grid grid-cols-2 gap-8 mb-6">
                      <div>
                        <h3 className="font-bold text-gray-700 mb-2">Employee Details</h3>
                        <table className="w-full text-sm">
                          <tbody>
                            <tr>
                              <td className="py-1 text-gray-600">Employee ID:</td>
                              <td className="py-1 font-medium">{employee.employeeId}</td>
                            </tr>
                            <tr>
                              <td className="py-1 text-gray-600">Name:</td>
                              <td className="py-1 font-medium">{employee.firstName} {employee.lastName}</td>
                            </tr>
                            <tr>
                              <td className="py-1 text-gray-600">Designation:</td>
                              <td className="py-1 font-medium">{employee.designation}</td>
                            </tr>
                            <tr>
                              <td className="py-1 text-gray-600">Department:</td>
                              <td className="py-1 font-medium">{employee.department}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-700 mb-2">Payment Details</h3>
                        <table className="w-full text-sm">
                          <tbody>
                            <tr>
                              <td className="py-1 text-gray-600">Pay Period:</td>
                              <td className="py-1 font-medium">{getMonthName(selectedPayslip.month)} 1-30, {selectedPayslip.year}</td>
                            </tr>
                            <tr>
                              <td className="py-1 text-gray-600">Payment Date:</td>
                              <td className="py-1 font-medium">
                                {(() => {
                                  const payroll = getPayrollDetails(selectedPayslip.payrollId);
                                  return payroll && payroll.paymentDate ? formatDate(payroll.paymentDate) : 'Pending';
                                })()}
                              </td>
                            </tr>
                            <tr>
                              <td className="py-1 text-gray-600">Bank:</td>
                              <td className="py-1 font-medium">{employee.bankName}</td>
                            </tr>
                            <tr>
                              <td className="py-1 text-gray-600">Account:</td>
                              <td className="py-1 font-medium">••••••{employee.accountNumber.slice(-4)}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })()}

                {/* Salary Breakdown */}
                {(() => {
                  const payroll = getPayrollDetails(selectedPayslip.payrollId);
                  if (!payroll) return <p>Payroll information not available</p>;
                  
                  return (
                    <div className="mb-6">
                      <div className="grid grid-cols-2 gap-8">
                        <div>
                          <h3 className="font-bold text-gray-700 mb-2 pb-1 border-b">Earnings</h3>
                          <table className="w-full text-sm">
                            <tbody>
                              <tr>
                                <td className="py-2 text-gray-600">Basic Salary</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.basicSalary)}</td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-600">House Rent Allowance</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalAllowances * 0.6)}</td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-600">Transport Allowance</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalAllowances * 0.2)}</td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-600">Medical Allowance</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalAllowances * 0.15)}</td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-600">Other Allowances</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalAllowances * 0.05)}</td>
                              </tr>
                              {payroll.totalBonus > 0 && (
                                <tr>
                                  <td className="py-2 text-gray-600">Bonus</td>
                                  <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalBonus)}</td>
                                </tr>
                              )}
                              <tr className="border-t">
                                <td className="py-2 font-bold">Total Earnings</td>
                                <td className="py-2 font-bold text-right">{formatCurrency(payroll.grossEarnings)}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-700 mb-2 pb-1 border-b">Deductions</h3>
                          <table className="w-full text-sm">
                            <tbody>
                              <tr>
                                <td className="py-2 text-gray-600">Income Tax</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalDeductions * 0.8)}</td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-600">Provident Fund</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalDeductions * 0.15)}</td>
                              </tr>
                              <tr>
                                <td className="py-2 text-gray-600">Other Deductions</td>
                                <td className="py-2 font-medium text-right">{formatCurrency(payroll.totalDeductions * 0.05)}</td>
                              </tr>
                              <tr className="border-t">
                                <td className="py-2 font-bold">Total Deductions</td>
                                <td className="py-2 font-bold text-right">{formatCurrency(payroll.totalDeductions)}</td>
                              </tr>
                            </tbody>
                          </table>
                          
                          <div className="mt-8 pt-4 border-t-2 border-gray-300">
                            <table className="w-full text-sm">
                              <tbody>
                                <tr>
                                  <td className="py-2 font-bold text-lg">Net Pay</td>
                                  <td className="py-2 font-bold text-lg text-right">{formatCurrency(payroll.netSalary)}</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Footer */}
                <div className="mt-10 pt-4 border-t text-center text-sm text-gray-600">
                  <p>This is a computer-generated document. No signature is required.</p>
                  <p className="mt-1">For any queries regarding this pay slip, please contact HR at hr@{currentTenant.subdomain}.com</p>
                </div>
              </div>
            </div>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsPreviewDialogOpen(false)}>
              Close
            </Button>
            <Button>
              Download PDF
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
